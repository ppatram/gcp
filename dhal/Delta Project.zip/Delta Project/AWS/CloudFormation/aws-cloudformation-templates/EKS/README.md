# EKS on EC2

## Features

- EKS cluster on EC2

## Configuration diagram

![diagram](./eks_ec2_diagram.png)

## After creating the stack

- Apply manifest.yml to the eks cluster.

## Before delete the stack

- Delete the pod and service created.
